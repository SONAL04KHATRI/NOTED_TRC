import SwiftUI
import UserNotifications

// MARK: - Onboarding Screen
struct OnboardingView: View {
    @State private var isOnboardingComplete = false
    @Environment(\.colorScheme) var colorScheme
    
    var body: some View {
        NavigationView {
            ZStack {
                Color(colorScheme == .dark ? .black : .white)
                    .edgesIgnoringSafeArea(.all)
                
                VStack(spacing: 30) {
                    Text("Welcome to Noted")
                        .font(.largeTitle)
                        .bold()
                        .foregroundColor(.red)
                    
                    VStack(spacing: 15) {
                        OnboardingStep(icon: "checklist", title: "Tasks", description: "Organize your daily tasks with categories and check them off.")
                        OnboardingStep(icon: "bell", title: "Reminders", description: "Set reminders for important events with custom purposes.")
                        OnboardingStep(icon: "calendar", title: "Schedules", description: "Plan your day with schedules, notifications, and easy deletion.")
                    }
                    .padding()
                    
                    Button(action: {
                        UserDefaults.standard.set(false, forKey: "isFirstLaunch")
                        isOnboardingComplete = true
                    }) {
                        Text("Get Started")
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                    }
                    .padding()
                }
            }
            .navigationBarHidden(true)
        }
        .fullScreenCover(isPresented: $isOnboardingComplete) {
            ContentView()
        }
    }
}

struct OnboardingStep: View {
    let icon: String
    let title: String
    let description: String
    
    var body: some View {
        HStack(alignment: .center, spacing: 15) {
            Image(systemName: icon)
                .font(.title2)
                .foregroundColor(.red)
                .frame(width: 30, height: 30, alignment: .center)
                .scaledToFit()
            
            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                    .foregroundColor(.primary)
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}

// MARK: - Main Content View
struct ContentView: View {
    var body: some View {
        TabView {
            TasksView()
                .tabItem {
                    Image(systemName: "checklist")
                    Text("Tasks")
                }
            
            RemindersView()
                .tabItem {
                    Image(systemName: "bell")
                    Text("Reminders")
                }
            
            SchedulesView()
                .tabItem {
                    Image(systemName: "calendar")
                    Text("Schedules")
                }
        }
        .accentColor(.blue)
    }
}

// MARK: - Header View
struct HeaderView: View {
    let title: String
    let action: () -> Void
    
    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 34, weight: .bold))
                .frame(maxWidth: .infinity, alignment: .leading)
            Spacer()
            Button(action: action) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 30))
                    .foregroundColor(.blue)
            }
        }
        .padding(.horizontal)
        .padding(.top)
    }
}

// MARK: - Empty State View
struct EmptyStateView: View {
    let icon: String
    let text: String
    
    var body: some View {
        VStack {
            Image(systemName: icon)
                .font(.largeTitle)
                .foregroundColor(.gray)
            Text(text)
                .multilineTextAlignment(.center)
                .foregroundColor(.gray)
                .padding()
        }
    }
}

// MARK: - Tasks Screen
struct TasksView: View {
    @State private var showTaskForm = false
    @State private var taskTitle = ""
    @State private var taskDescription = ""
    @State private var selectedCategory = "Visit"
    @State private var tasks: [(title: String, description: String, category: String, isChecked: Bool, checkTime: Date?)] = []

    let categories = [
        "Visit": "mappin.and.ellipse",
        "Education": "book.fill",
        "Financial": "dollarsign.circle.fill",
        "Social Task": "person.3.fill",
        "Work Task": "briefcase.fill",
        "Shopping Task": "cart.fill",
        "Personal Task": "person.fill",
        "Health Task": "heart.fill"
    ]

    let categoryColors: [String: Color] = [
        "Visit": .yellow,
        "Education": .blue,
        "Financial": .green,
        "Social Task": .orange,
        "Work Task": .cyan,
        "Shopping Task": .purple,
        "Personal Task": .white,
        "Health Task": .red
    ]

    var body: some View {
        NavigationView {
            ZStack {
                VStack {
                    HeaderView(title: "Tasks", action: {
                        showTaskForm.toggle()
                    })

                    if tasks.isEmpty {
                        Spacer()
                        EmptyStateView(icon: "checklist", text: "Seems like you are all done!\nWant to add new tasks?")
                        Spacer()
                    } else {
                        List {
                            ForEach(tasks.indices, id: \.self) { index in
                                HStack(spacing: 10) {
                                    Button(action: {
                                        toggleTaskCheck(at: index)
                                    }) {
                                        Image(systemName: tasks[index].isChecked ? "checkmark.circle.fill" : "circle")
                                            .foregroundColor(tasks[index].isChecked ? .green : .gray)
                                    }
                                    
                                    VStack(alignment: .leading) {
                                        Text(tasks[index].title)
                                            .font(.title3)
                                            .bold()
                                        Text(tasks[index].description)
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    
                                    Spacer()
                                    
                                    if tasks[index].isChecked {
                                        Button(action: {
                                            deleteTask(at: index)
                                        }) {
                                            Image(systemName: "trash")
                                                .foregroundColor(.red)
                                        }
                                    }
                                    
                                    if let icon = categories[tasks[index].category] {
                                        Image(systemName: icon)
                                            .foregroundColor(categoryColors[tasks[index].category] ?? .gray)
                                            .font(.title2)
                                    } else {
                                        Image(systemName: "questionmark.circle.fill")
                                            .foregroundColor(.gray)
                                    }
                                }
                                .padding(.vertical, 5)
                            }
                        }
                    }
                }
                .padding()
                .blur(radius: showTaskForm ? 5 : 0)
                
                if showTaskForm {
                    FloatingTaskForm(
                        taskTitle: $taskTitle,
                        taskDescription: $taskDescription,
                        selectedCategory: $selectedCategory,
                        categories: categories,
                        onAddTask: {
                            if !taskTitle.isEmpty {
                                tasks.append((title: taskTitle, description: taskDescription, category: selectedCategory, isChecked: false, checkTime: nil))
                                taskTitle = ""
                                taskDescription = ""
                                showTaskForm.toggle()
                            }
                        },
                        onClose: {
                            showTaskForm.toggle()
                        }
                    )
                }
            }
        }
    }

    private func toggleTaskCheck(at index: Int) {
        tasks[index].isChecked.toggle()
        tasks[index].checkTime = tasks[index].isChecked ? Date() : nil
    }
    
    private func deleteTask(at index: Int) {
        withAnimation {
            tasks.remove(at: index)
        }
    }
}

// MARK: - Floating Task Form
struct FloatingTaskForm: View {
    @Binding var taskTitle: String
    @Binding var taskDescription: String
    @Binding var selectedCategory: String
    let categories: [String: String]
    let onAddTask: () -> Void
    let onClose: () -> Void
    
    @Environment(\.colorScheme) var colorScheme

    let categoryColors: [String: Color] = [
        "Visit": .yellow,
        "Education": .blue,
        "Financial": .green,
        "Social Task": .orange,
        "Work Task": .cyan,
        "Shopping Task": .purple,
        "Personal Task": .white,
        "Health Task": .red
    ]

    var body: some View {
        VStack(spacing: 20) {
            Text("New Task")
                .font(.title2)
                .bold()
                .padding(.bottom, 5)
            
            VStack(alignment: .leading, spacing: 5) {
                Text("Title")
                    .font(.caption)
                    .foregroundColor(.gray)
                TextField("Enter task title", text: $taskTitle)
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal)

            VStack(alignment: .leading, spacing: 5) {
                Text("Description")
                    .font(.caption)
                    .foregroundColor(.gray)
                TextField("Enter task description", text: $taskDescription)
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal)

            VStack(alignment: .leading, spacing: 5) {
                Text("Category")
                    .font(.caption)
                    .foregroundColor(.gray)
                Menu {
                    ForEach(categories.keys.sorted(), id: \.self) { category in
                        Button(action: { selectedCategory = category }) {
                            HStack {
                                Image(systemName: categories[category] ?? "questionmark.circle.fill")
                                    .foregroundColor(categoryColors[category] ?? .gray)
                                Text(category)
                                    .foregroundColor(.primary)
                            }
                        }
                    }
                } label: {
                    HStack {
                        if let icon = categories[selectedCategory] {
                            Image(systemName: icon)
                                .foregroundColor(categoryColors[selectedCategory] ?? .gray)
                        }
                        Text(selectedCategory.isEmpty ? "Select Category" : selectedCategory)
                        Spacer()
                        Image(systemName: "chevron.down")
                            .foregroundColor(.gray)
                    }
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
                }
            }
            .padding(.horizontal)

            HStack {
                Button(action: onClose) {
                    Text("Cancel")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Capsule().fill(Color.red.opacity(0.2)))
                        .foregroundColor(.red)
                }

                Button(action: onAddTask) {
                    Text("Done")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Capsule().fill(Color.blue))
                        .foregroundColor(.white)
                }
            }
            .padding(.horizontal)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15)
                        .fill(colorScheme == .dark ? Color.black : Color.white))
        .shadow(radius: 10)
        .frame(width: 350)
    }
}

// MARK: - Reminder Screen
struct Reminder: Identifiable, Codable {
    let id: UUID
    var title: String
    var purpose: String
    var frequency: String
    var time: Date
    var isActive: Bool
    var activationTime: Date?
    
    init(id: UUID = UUID(), title: String, purpose: String, frequency: String, time: Date, isActive: Bool = false, activationTime: Date? = nil) {
        self.id = id
        self.title = title
        self.purpose = purpose
        self.frequency = frequency
        self.time = time
        self.isActive = isActive
        self.activationTime = activationTime
    }
}

struct RemindersView: View {
    @State private var showReminderForm = false
    @State private var reminderTitle = ""
    @State private var selectedPurpose = "Medicine"
    @State private var selectedFrequency = "Daily"
    @State private var reminderTime = Date()
    @State private var reminders: [Reminder] = []
    
    let purposes = [
        "Medicine": "pill.fill",
        "Gym": "dumbbell.fill",
        "Work": "briefcase.fill",
        "Personal": "person.fill",
        "Custom": "gearshape.fill"
    ]
    
    let purposeColors: [String: Color] = [
        "Medicine": .red,
        "Gym": .green,
        "Work": .cyan,
        "Personal": .orange,
        "Custom": .purple
    ]
    
    func formattedTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        return formatter.string(from: date)
    }
    
    func deleteReminder(at offsets: IndexSet) {
        reminders.remove(atOffsets: offsets)
    }

    var body: some View {
        NavigationView {
            ZStack {
                VStack {
                    HeaderView(title: "Reminders", action: {
                        showReminderForm.toggle()
                    })
                    
                    if reminders.isEmpty {
                        Spacer()
                        VStack {
                            Image(systemName: "alarm.fill")
                                .font(.system(size: 50))
                                .foregroundColor(.gray)
                            Text("No reminders yet!\nWant to set some?")
                                .multilineTextAlignment(.center)
                                .foregroundColor(.gray)
                                .padding(.top, 10)
                        }
                        Spacer()
                    } else {
                        List {
                            ForEach(reminders.indices, id: \.self) { index in
                                HStack(spacing: 10) {
                                    VStack(alignment: .leading) {
                                        Text(reminders[index].title)
                                            .font(.title3)
                                            .bold()
                                        Text("Frequency: \(reminders[index].frequency)")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                        Text("Time: \(formattedTime(reminders[index].time))")
                                            .font(.subheadline)
                                            .foregroundColor(.gray)
                                    }
                                    
                                    Spacer()
                                    if let icon = purposes[reminders[index].purpose] {
                                        Image(systemName: icon)
                                            .foregroundColor(purposeColors[reminders[index].purpose] ?? .gray)
                                            .font(.title2)
                                    } else {
                                        Image(systemName: "questionmark.circle.fill")
                                            .foregroundColor(.gray)
                                    }
                                }
                                .padding(.vertical, 5)
                            }
                            .onDelete(perform: deleteReminder)
                        }
                    }
                }
                .padding()
                .blur(radius: showReminderForm ? 5 : 0)
                
                if showReminderForm {
                    VStack(spacing: 20) {
                        Text("New Reminder")
                            .font(.title2)
                            .bold()
                            .padding(.bottom, 5)
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Title")
                                .font(.caption)
                                .foregroundColor(.gray)
                            TextField("Enter reminder title", text: $reminderTitle)
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color.gray.opacity(0.15)))
                        }
                        .padding(.horizontal)
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Purpose")
                                .font(.caption)
                                .foregroundColor(.gray)
                            Menu {
                                ForEach(purposes.keys.sorted(), id: \.self) { purpose in
                                    Button(action: { selectedPurpose = purpose }) {
                                        HStack {
                                            Image(systemName: purposes[purpose] ?? "questionmark.circle.fill")
                                                .foregroundColor(purposeColors[purpose] ?? .gray)
                                            Text(purpose)
                                        }
                                    }
                                }
                            } label: {
                                HStack {
                                    if let icon = purposes[selectedPurpose] {
                                        Image(systemName: icon)
                                            .foregroundColor(purposeColors[selectedPurpose] ?? .gray)
                                    }
                                    Text(selectedPurpose)
                                    Spacer()
                                    Image(systemName: "chevron.down")
                                        .foregroundColor(.gray)
                                }
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color.gray.opacity(0.15)))
                            }
                        }
                        .padding(.horizontal)
                        
                        VStack(alignment: .leading, spacing: 5) {
                            Text("Time")
                                .font(.caption)
                                .foregroundColor(.gray)
                            DatePicker("Select Time", selection: $reminderTime, displayedComponents: .hourAndMinute)
                                .labelsHidden()
                                .padding()
                                .background(RoundedRectangle(cornerRadius: 10).fill(Color.gray.opacity(0.15)))
                        }
                        .padding(.horizontal)
                        
                        HStack {
                            Button("Cancel") {
                                showReminderForm = false
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.red.opacity(0.2))
                            .foregroundColor(.red)
                            .cornerRadius(10)
                            
                            Button("Done") {
                                if !reminderTitle.isEmpty {
                                    let reminder = Reminder(
                                        title: reminderTitle,
                                        purpose: selectedPurpose,
                                        frequency: selectedFrequency,
                                        time: reminderTime
                                    )
                                    reminders.append(reminder)
                                    reminderTitle = ""
                                    showReminderForm = false
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                        }
                        .padding()
                    }
                    .frame(width: 350)
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 15).fill(Color.white))
                    .shadow(radius: 10)
                }
            }
        }
    }
}

// MARK: - Schedules Screen
struct Schedule: Identifiable, Codable {
    let id: UUID
    var title: String
    var description: String
    var date: Date
    var time: Date
    var duration: TimeInterval
    var type: ScheduleType
    var notificationId: String
    
    init(id: UUID = UUID(), title: String, description: String, date: Date, time: Date, duration: TimeInterval, type: ScheduleType) {
        self.id = id
        self.title = title
        self.description = description
        self.date = date
        self.time = time
        self.duration = duration
        self.type = type
        self.notificationId = id.uuidString
    }
}

enum ScheduleType: String, CaseIterable, Codable {
    case meeting = "Meeting"
    case personal = "Personal"
    case work = "Work"
    case other = "Other"
    
    var color: Color {
        switch self {
        case .meeting: return .blue
        case .personal: return .green
        case .work: return .purple
        case .other: return .orange
        }
    }
}

class ScheduleManager: ObservableObject {
    @Published var schedules: [Schedule] = []
    
    init() {
        requestNotificationPermissions()
    }
    
    func addSchedule(_ schedule: Schedule) {
        schedules.append(schedule)
        scheduleNotification(for: schedule)
    }
    
    func deleteSchedule(_ schedule: Schedule) {
        schedules.removeAll { $0.id == schedule.id }
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: [schedule.notificationId])
    }
    
    private func requestNotificationPermissions() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound]) { granted, error in
            if let error = error {
                print("Error requesting notification permissions: \(error)")
            }
        }
    }
    
    private func scheduleNotification(for schedule: Schedule) {
        let content = UNMutableNotificationContent()
        content.title = "Upcoming Schedule: \(schedule.title)"
        content.body = "Your schedule starts in 1 hour"
        content.sound = .default
        
        let notificationTime = Calendar.current.date(byAdding: .hour, value: -1, to: schedule.time) ?? schedule.time
        let components = Calendar.current.dateComponents([.year, .month, .day, .hour, .minute], from: notificationTime)
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        
        let request = UNNotificationRequest(identifier: schedule.notificationId, content: content, trigger: trigger)
        UNUserNotificationCenter.current().add(request)
    }
}

struct ScheduleCell: View {
    let schedule: Schedule
    let onDelete: () -> Void
    
    var body: some View {
        HStack(alignment: .center, spacing: 8) {
            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Text(schedule.title)
                        .font(.headline)
                    Spacer()
                    Text(formatTime(schedule.time))
                        .font(.subheadline)
                        .foregroundColor(.blue)
                }
                
                if !schedule.description.isEmpty {
                    Text(schedule.description)
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }
                
                HStack {
                    Text(formatDuration(schedule.duration))
                        .font(.caption)
                    Text(schedule.type.rawValue)
                        .font(.caption)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(schedule.type.color.opacity(0.2))
                        .cornerRadius(8)
                }
            }
            
            Button(action: {
                withAnimation {
                    onDelete()
                }
            }) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
                    .frame(width: 30, height: 30)
            }
            .buttonStyle(PlainButtonStyle())
        }
        .padding()
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(schedule.type.color.opacity(0.1))
        .cornerRadius(12)
    }
    
    private func formatTime(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mm a"
        return formatter.string(from: date)
    }
    
    private func formatDuration(_ duration: TimeInterval) -> String {
        let hours = Int(duration) / 3600
        let minutes = (Int(duration) % 3600) / 60
        return hours > 0 ? "\(hours)h \(minutes)m" : "\(minutes)m"
    }
}

struct DateCell: View {
    let date: Date
    let isSelected: Bool
    
    var body: some View {
        VStack {
            Text(formatWeekday(date))
                .font(.caption)
                .foregroundColor(.gray)
            Text(date.formatted(.dateTime.day()))
                .font(.title2)
                .frame(width: 50, height: 50)
                .background(isSelected ? Color.blue : Color.clear)
                .clipShape(Circle())
                .foregroundColor(isSelected ? .white : .primary)
                .scaleEffect(isSelected ? 1.3 : 1.0)
                .bold()
                .shadow(color: isSelected ? Color.blue.opacity(0.5) : .clear, radius: 5)
        }
    }
    
    private func formatWeekday(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEE"
        return formatter.string(from: date).uppercased()
    }
}

struct FloatingScheduleForm: View {
    @Binding var title: String
    @Binding var description: String
    @Binding var scheduleTime: Date
    @Binding var duration: TimeInterval
    @Binding var type: ScheduleType
    let selectedDate: Date
    let onAddSchedule: () -> Void
    let onClose: () -> Void
    
    @Environment(\.colorScheme) var colorScheme

    var body: some View {
        VStack(spacing: 20) {
            Text("New Schedule")
                .font(.title2)
                .bold()
                .padding(.bottom, 5)
            
            VStack(alignment: .leading, spacing: 5) {
                Text("Title")
                    .font(.caption)
                    .foregroundColor(.gray)
                TextField("Enter schedule title", text: $title)
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal)

            VStack(alignment: .leading, spacing: 5) {
                Text("Description")
                    .font(.caption)
                    .foregroundColor(.gray)
                TextField("Enter schedule description", text: $description)
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal)

            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Time")
                        .font(.caption)
                        .foregroundColor(.gray)
                    DatePicker("", selection: $scheduleTime, displayedComponents: .hourAndMinute)
                        .labelsHidden()
                        .padding()
                        .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                        .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
                }
                .frame(maxWidth: .infinity)

                VStack(alignment: .leading, spacing: 5) {
                    Text("Duration")
                        .font(.caption)
                        .foregroundColor(.gray)
                    Picker("", selection: $duration) {
                        Text("30 min").tag(TimeInterval(1800))
                        Text("1 hr").tag(TimeInterval(3600))
                        Text("2 hrs").tag(TimeInterval(7200))
                        Text("3 hrs").tag(TimeInterval(10800))
                    }
                    .pickerStyle(MenuPickerStyle())
                    .padding()
                    .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                    .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
                }
                .frame(maxWidth: .infinity)
            }
            .padding(.horizontal)

            VStack(alignment: .leading, spacing: 5) {
                Text("Type")
                    .font(.caption)
                    .foregroundColor(.gray)
                Picker("", selection: $type) {
                    ForEach(ScheduleType.allCases, id: \.self) { type in
                        Text(type.rawValue).tag(type)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .padding()
                .background(Capsule().fill(colorScheme == .dark ? Color.white.opacity(0.2) : Color.gray.opacity(0.15)))
                .overlay(Capsule().stroke(Color.gray.opacity(0.3), lineWidth: 1))
            }
            .padding(.horizontal)

            HStack {
                Button(action: onClose) {
                    Text("Cancel")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Capsule().fill(Color.red.opacity(0.2)))
                        .foregroundColor(.red)
                }

                Button(action: onAddSchedule) {
                    Text("Done")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Capsule().fill(Color.blue))
                        .foregroundColor(.white)
                }
                .disabled(title.isEmpty)
            }
            .padding(.horizontal)
        }
        .padding()
        .background(RoundedRectangle(cornerRadius: 15)
                        .fill(colorScheme == .dark ? Color.black : Color.white))
        .shadow(radius: 10)
        .frame(width: 350)
    }
}

struct SchedulesView: View {
    @StateObject private var scheduleManager = ScheduleManager()
    @State private var selectedDate = Date()
    @State private var showMonthPicker = false
    @State private var showAddSchedule = false
    
    @State private var title = ""
    @State private var description = ""
    @State private var scheduleTime = Date()
    @State private var duration: TimeInterval = 3600
    @State private var type: ScheduleType = .meeting
    
    private var filteredSchedules: [Schedule] {
        scheduleManager.schedules
            .filter { Calendar.current.isDate($0.date, inSameDayAs: selectedDate) }
            .sorted { $0.time < $1.time }
    }
    
    var body: some View {
        NavigationView {
            ZStack {
                VStack(spacing: 20) {
                    HeaderView(title: "Schedules", action: {
                        showAddSchedule.toggle()
                    })
                    
                    Button(action: { showMonthPicker.toggle() }) {
                        Text(selectedDate.formatted(.dateTime.month().year()))
                            .font(.title2)
                            .foregroundColor(.blue)
                    }
                    .sheet(isPresented: $showMonthPicker) {
                        VStack {
                            DatePicker("Select Month", selection: $selectedDate, displayedComponents: [.date])
                                .datePickerStyle(.graphical)
                                .accentColor(.blue)
                                .padding()
                            Button("Done") {
                                showMonthPicker = false
                            }
                            .padding()
                            .foregroundColor(.blue)
                        }
                    }
                    
                    ScrollViewReader { proxy in
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack(spacing: 15) {
                                ForEach(getDateRange(), id: \.self) { date in
                                    DateCell(date: date, isSelected: Calendar.current.isDate(date, inSameDayAs: selectedDate))
                                        .onTapGesture {
                                            withAnimation {
                                                selectedDate = date
                                                proxy.scrollTo(date, anchor: .center)
                                            }
                                        }
                                        .id(date)
                                }
                            }
                            .padding()
                        }
                        .onAppear {
                            proxy.scrollTo(selectedDate, anchor: .center)
                        }
                        .onChange(of: selectedDate) { _ in
                            withAnimation {
                                proxy.scrollTo(selectedDate, anchor: .center)
                            }
                        }
                    }
                    
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            if filteredSchedules.isEmpty {
                                Text("No schedules for this day")
                                    .foregroundColor(.gray)
                                    .padding()
                            } else {
                                ForEach(filteredSchedules) { schedule in
                                    ScheduleCell(schedule: schedule, onDelete: {
                                        scheduleManager.deleteSchedule(schedule)
                                    })
                                    .contextMenu {
                                        Button(role: .destructive) {
                                            scheduleManager.deleteSchedule(schedule)
                                        } label: {
                                            Label("Delete", systemImage: "trash")
                                        }
                                    }
                                }
                            }
                        }
                        .padding()
                    }
                }
                .blur(radius: showAddSchedule ? 5 : 0)
                
                if showAddSchedule {
                    FloatingScheduleForm(
                        title: $title,
                        description: $description,
                        scheduleTime: $scheduleTime,
                        duration: $duration,
                        type: $type,
                        selectedDate: selectedDate,
                        onAddSchedule: {
                            if !title.isEmpty {
                                saveSchedule()
                                resetForm()
                                showAddSchedule.toggle()
                            }
                        },
                        onClose: {
                            showAddSchedule.toggle()
                        }
                    )
                }
            }
        }
    }
    
    private func saveSchedule() {
        let calendar = Calendar.current
        let timeComponents = calendar.dateComponents([.hour, .minute], from: scheduleTime)
        let fullDateTime = calendar.date(bySettingHour: timeComponents.hour ?? 0,
                                       minute: timeComponents.minute ?? 0,
                                       second: 0,
                                       of: selectedDate) ?? selectedDate
        
        let schedule = Schedule(
            title: title,
            description: description,
            date: selectedDate,
            time: fullDateTime,
            duration: duration,
            type: type
        )
        
        scheduleManager.addSchedule(schedule)
    }
    
    private func resetForm() {
        title = ""
        description = ""
        scheduleTime = Date()
        duration = 3600
        type = .meeting
    }
    
    private func getDateRange() -> [Date] {
        let calendar = Calendar.current
        var dates: [Date] = []
        for offset in -15...15 {
            if let date = calendar.date(byAdding: .day, value: offset, to: selectedDate) {
                dates.append(date)
            }
        }
        return dates
    }
}

// MARK: - App Entry Point


// MARK: - Preview
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.light)
            .previewDevice("iPhone 16 Pro")
    }
}
